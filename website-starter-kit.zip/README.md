# 502ai Website Starter Kit

Ready-to-edit one-page website templates for local businesses. Customize, deploy, and go live in minutes.

## What's Included

| Template | Best For | File |
|----------|----------|------|
| Restaurant | Restaurants, cafes, food service | `templates/index-restaurant.html` |
| Plumber | Plumbers, HVAC, trade services | `templates/index-plumber.html` |
| Generic Business | Consultants, agencies, professional services | `templates/index-generic.html` |
| Fitness Studio | Gyms, yoga studios, personal trainers | `templates/index-fitness.html` |

Each template is a **single HTML file** with embedded CSS — no build step, no dependencies.

## Quick Start

1. **Pick a template** — choose the file that matches your business type
2. **Customize** — open in any code editor (VS Code, Notepad++, etc.) and replace:
   - Business name, tagline, contact info
   - Services, menu items, class schedules, pricing
   - Colors (search for `#b7f34b` — the lime accent — and `#0b1424` — the navy)
   - Images (replace placeholder URLs with your own)
3. **Deploy** — upload to any static host:
   - **Netlify**: drag & drop the folder
   - **Vercel**: `vercel deploy`
   - **GitHub Pages**: push to a repo, enable Pages
   - **Any web server**: upload via FTP/SFTP

## Customization Guide

### Colors
The kit uses two primary colors:
- **Navy** (`#0b1424`) — backgrounds, headers, text
- **Lime** (`#b7f34b`) — buttons, accents, highlights

Search and replace these hex values to match your brand.

### Fonts
Templates use system fonts (`-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif`). No external font loading needed. To use Google Fonts, add a `<link>` in `<head>` and update `font-family` in CSS.

### Images
All templates use placeholder images or SVG icons. Replace with your own:
- Hero background: add a `background-image` to `.hero` in CSS
- Team photos: replace `.trainer-avatar` divs with `<img>` tags
- Service icons: inline SVGs can be swapped for `<img>` or icon fonts

### Forms
Forms use `mailto:` links or basic HTML forms. For production:
- **Netlify Forms**: add `data-netlify="true"` to `<form>`
- **Formspree**: change `action` to your Formspree endpoint
- **Custom backend**: update `action` and `method` attributes

## Browser Support
Modern browsers (last 2 versions of Chrome, Firefox, Safari, Edge). No IE11 support.

## License
MIT — use for client projects, personal sites, or resell as part of your services.

## Support
Questions? Email **info@502ai.pro**

---

Built by [502ai](https://502ai.pro) — AI integration, workflow automation & IT consultation for small businesses.
